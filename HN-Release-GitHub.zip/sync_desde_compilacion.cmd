@echo off
setlocal
chcp 65001 >nul
set "ROOT=%~dp0"
set "SRC=%ROOT%..\HN_cpp\build\bin\Release"
set "DST=%ROOT%"
if not exist "%SRC%\HN.exe" (
  echo [ERROR] No existe "%SRC%\HN.exe"
  echo Compila primero en Visual Studio / CMake: configuración Release.
  exit /b 1
)
copy /Y "%SRC%\HN.exe" "%DST%" || exit /b 1
if not exist "%DST%assets" mkdir "%DST%assets"
if exist "%SRC%\assets\skull_phuniser.png" (
  copy /Y "%SRC%\assets\skull_phuniser.png" "%DST%assets\" || exit /b 1
) else (
  copy /Y "%ROOT%..\HN_cpp\assets\skull_phuniser.png" "%DST%assets\" || exit /b 1
)
echo.
echo Listo. HN.exe y assets actualizados en HNcompartir.
echo Siguiente paso: comprime esta carpeta entera en un .zip para GitHub o distribución.
exit /b 0
